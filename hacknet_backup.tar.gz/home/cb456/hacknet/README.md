code
Markdown
# CB456 HackNet Engine 🚀
**Zero-Bloat, Bare-Metal NOC Appliance**

The CB456 HackNet Engine is a dedicated, physical Network Operations Center (NOC) monitor. It actively polls network routes, Proxmox hypervisors (VMs/LXCs), web services (TCP), and Pterodactyl Game Servers. It displays the status on a physical SPI TFT screen and sends escalated alerts to Telegram.

---

## 🛠️ Hardware & Environment
* **Hardware:** Raspberry Pi 3B
* **Display:** Joy-IT 3.2" TFT SPI LCD (320x240 Resolution, Non-Touch)
* **OS:** Raspberry Pi OS **Lite** (32-bit)
* **Display Server:** Bare-Metal X11 + Openbox (No Desktop Environment)
* **Database:** SQLite 3 (WAL Mode enabled for concurrent Read/Write)
* **Core Stack:** Python 3, FastAPI, pure HTML/CSS/JS (Zero external libraries)

---

## 🎛️ The Physical Appliance Controls
The Joy-IT screen features three physical buttons wired to the Pi's GPIO pins. The backend tracks short vs. long presses to create a full hardware UI.

**DASHBOARD MODE:**
* **Top (Short):** Next Page
* **Top (Long >2s):** Return to Home (Page 1 Overview)
* **Middle (Short):** Force Poll & Send Telegram Report
* **Middle (Long >5s):** Hard Reboot the Pi
* **Bottom (Short):** Toggle `[FAILS ONLY]` Filter
* **Bottom (Long >2s):** Enter `[CONFIG MODE]`

**CONFIG MODE:**
* **Top:** Scroll to Next Sensor
* **Middle:** Toggle Sensor (ACTIVE / PAUSED)
* **Bottom:** Save & Exit to Dashboard

---

## 📂 Architecture & Services

The system is decoupled into three distinct layers:

1. **`hacknet-collector.service` (`collector.py`)**
   * The backend engine. Runs on a continuous loop.
   * Scans Proxmox, pings networks, checks TCP ports, and queries Pterodactyl.
   * Auto-discovers Proxmox VMs/LXCs and registers them in the database.
   * Listens to GPIO hardware buttons via background threads.
   * Manages the Telegram Alerting state machine.

2. **`hacknet-api.service` (`api.py`)**
   * A stateless FastAPI web server.
   * Serves the internal `kiosk.html` to the physical screen.
   * Serves the external `admin.html` web portal to your PC browser.
   * Acts as the IPC (Inter-Process Communication) router between the GPIO buttons and the HTML frontend.

3. **`hacknet-gui.service` (`.xinitrc`)**
   * The graphical display engine.
   * Uses `xserver-xorg` to bypass the Linux terminal and paint a pure black screen.
   * Launches Chromium fullscreen in Kiosk mode.
   * Hides the mouse cursor via `unclutter`.

---

## 🧠 Smart Alerting Logic
To prevent alert fatigue and false positives (e.g., a 1-second network blip):
* **Trigger Threshold:** A service must fail 3 consecutive polls (30 seconds) before an alert is fired.
* **Network Flapping:** ICMP pings send 3 packets per poll. If *any* packet returns, the network is considered Online.
* **Standard Cooldown:** Once alerted, the system will not nag you again for **1 Hour**.
* **Game Server Escalation:** Game servers drop to a **24 Hour** nag cooldown if they are offline for more than a day.
* **Proxmox Cascade:** If the primary Proxmox API goes offline, the system safely marks all underlying VMs and LXCs as `stopped` in the database to keep the dashboard accurate, but *bypasses* the Telegram trigger to prevent 20+ alerts from firing at once.

---

## ⚠️ Crucial Configuration Notes

### 1. Web Admin Portal
You **do not** need to SSH or edit Python files to add new targets. 
Open a web browser on your PC/Phone and go to: `http://<PI_IP_ADDRESS>:8000/admin`
From here, you can Add/Delete Network Pings, Web Apps, and Game Servers. 
*(Note: Proxmox VMs and LXCs cannot be added or deleted manually. The Collector auto-discovers them and manages them dynamically).*

### 2. Proxmox VM RAM Calculation (QEMU Guest Agent)
By default, Proxmox caches Linux filesystem memory, making VMs appear at 100% RAM usage. 
**Requirement:** To get accurate RAM metrics, the VM **must** have `qemu-guest-agent` installed, enabled in the Proxmox VM Options, and the VM must undergo a full Shutdown/Start cycle. The engine specifically queries this agent to calculate true `freemem`.

### 3. Database Maintenance
Because this app writes roughly 150,000 rows a day, the database is optimized using SQLite Write-Ahead Logging (`WAL`). An automatic `VACUUM` process runs exactly once a day at 3:00 AM to compress the database and preserve SD card lifespan without lagging the UI during the day.

---

## 🔧 Useful Commands

**Check Backend Logs (Collector or API):**
```bash
sudo systemctl status hacknet-collector.service --no-pager -l
sudo systemctl status hacknet-api.service --no-pager -l
Restart the Physical UI (If the screen ever glitches):
code
Bash
sudo systemctl restart hacknet-gui.service
Update the Boot Logo:
Upload a .jpeg or .png to /home/cb456/hacknet/static/
Run the conversion & injection command:
code
Bash
sudo convert /home/cb456/hacknet/static/your_logo.jpeg /usr/share/plymouth/themes/pix/splash.png
sudo plymouth-set-default-theme -R pix
sudo reboot
code
Code
Press `Ctrl+O`, `Enter`, and `Ctrl+X` to save and close the file.

Your project is completely documented, architected, and locked down. You can start a fresh chat anytime!
