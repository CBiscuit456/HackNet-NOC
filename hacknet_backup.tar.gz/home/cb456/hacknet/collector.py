import time
import sqlite3
import urllib3
import subprocess
import socket
import requests
import re
import os
import datetime
import threading
from proxmoxer import ProxmoxAPI

try:
    from gpiozero import Button
    GPIO_AVAILABLE = True
except ImportError:
    GPIO_AVAILABLE = False

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ==============================================================================
# ======================== SENSOR CREDENTIALS ==================================
# ==============================================================================
PROXMOX_IP = '10.10.50.50'
TOKEN_ID = 'root@pam!hacknet-monitor'
TOKEN_SECRET = '8ef57837-de56-4f59-a05d-299a810a7f0e'
IGNORE_ENTITIES = ['expanse-svr']

PTERO_URL = 'http://10.10.50.200'
PTERO_TOKEN = 'ptlc_n9O3V7vq7P6zmpJIZUwbo2rRfNZElxcCQMQwFwHGTL8'

TELEGRAM_TOKEN = '8873427127:AAGlP_Yey1_vKXZfVA3Zd6X5cNacnSgEBCA'
TELEGRAM_CHAT_ID = '8993367716'

POLL_INTERVAL = 10
DB_NAME = 'metrics.db'

# --- ALERT THRESHOLDS ---
STANDARD_COOLDOWN = 3600          
GAME_ESCALATION_TIME = 86400      
GAME_ESCALATION_COOLDOWN = 86400  
THRESHOLD_PCT = 90.0              

# ==============================================================================

ALERT_STATE = {}
LAST_DAILY_REPORT_DAY = None
LAST_VACUUM_DAY = None
FORCE_POLL_AND_REPORT = False

def send_telegram(message):
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {"chat_id": TELEGRAM_CHAT_ID, "text": message, "parse_mode": "HTML"}
    try: requests.post(url, json=payload, timeout=5)
    except Exception as e: print(f"-> FAILED TO SEND TG: {e}", flush=True)

def setup_database():
    conn = sqlite3.connect(DB_NAME, timeout=15)
    cursor = conn.cursor()
    cursor.execute('PRAGMA journal_mode=WAL;')
    cursor.execute('PRAGMA synchronous=NORMAL;')
    cursor.execute('''CREATE TABLE IF NOT EXISTS metrics (id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP, entity_name TEXT, entity_type TEXT, status TEXT, cpu_usage REAL, mem_used REAL, mem_total REAL, disk_used REAL, disk_total REAL, net_in REAL, net_out REAL, ping_ms REAL)''')
    
    cursor.execute('SELECT entity_metric, is_alerting, first_alert_time, last_alert_time, count FROM alert_state')
    for row in cursor.fetchall():
        ALERT_STATE[row[0]] = {'is_alerting': bool(row[1]), 'first_alert_time': row[2], 'last_alert_time': row[3], 'count': row[4]}
    
    conn.commit()
    conn.close()

def sync_alert_db(key, state):
    conn = sqlite3.connect(DB_NAME, timeout=15)
    cursor = conn.cursor()
    cursor.execute('PRAGMA journal_mode=WAL;')
    cursor.execute('''INSERT INTO alert_state (entity_metric, is_alerting, first_alert_time, last_alert_time, count) 
                      VALUES (?, ?, ?, ?, ?)
                      ON CONFLICT(entity_metric) DO UPDATE SET 
                      is_alerting=excluded.is_alerting, first_alert_time=excluded.first_alert_time, 
                      last_alert_time=excluded.last_alert_time, count=excluded.count''', 
                   (key, int(state['is_alerting']), state['first_alert_time'], state['last_alert_time'], state['count']))
    conn.commit()
    conn.close()

def process_alert(entity, metric, condition_met, trigger_count, msg_trigger, msg_recover, is_game=False):
    key = f"{entity}_{metric}"
    if key not in ALERT_STATE:
        ALERT_STATE[key] = {'count': 0, 'is_alerting': False, 'first_alert_time': 0, 'last_alert_time': 0}

    state = ALERT_STATE[key]
    state_changed = False

    if condition_met:
        if state['count'] < trigger_count:
            state['count'] += 1
            state_changed = True
            
        if state['count'] >= trigger_count:
            now = time.time()
            if not state['is_alerting']:
                send_telegram(f"🚨 <b>ALERT: {entity}</b>\n{msg_trigger}")
                state['is_alerting'] = True
                state['first_alert_time'] = now
                state['last_alert_time'] = now
                state_changed = True
            else:
                time_down = now - state['first_alert_time']
                cooldown = GAME_ESCALATION_COOLDOWN if (is_game and time_down >= GAME_ESCALATION_TIME) else STANDARD_COOLDOWN

                if (now - state['last_alert_time']) > cooldown:
                    hrs = int(time_down / 3600)
                    send_telegram(f"🚨 <b>REMINDER: {entity}</b>\n{msg_trigger} (Down for {hrs}h)")
                    state['last_alert_time'] = now
                    state_changed = True
    else:
        if state['is_alerting']:
            send_telegram(f"🟢 <b>RESOLVED: {entity}</b>\n{msg_recover}")
            state['is_alerting'] = False
            state['first_alert_time'] = 0
            state['count'] = 0
            state_changed = True
        elif state['count'] > 0:
            state['count'] = 0
            state_changed = True

    if state_changed:
        sync_alert_db(key, state)

def generate_full_report(title="📊 <b>NOC Status Report</b>"):
    conn = sqlite3.connect(DB_NAME, timeout=15)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('''SELECT m.entity_name, m.entity_type, m.status, m.ping_ms, m.cpu_usage, m.mem_used, t.is_enabled 
                      FROM metrics m 
                      LEFT JOIN monitored_targets t ON m.entity_name = t.name AND m.entity_type = t.entity_type
                      WHERE m.id IN (SELECT MAX(id) FROM metrics GROUP BY entity_name, entity_type)''')
    rows = cursor.fetchall()
    conn.close()

    net_down, vm_down, lxc_down, app_down, game_down = [], [], [], [], []
    vms_tot, lxc_tot, app_tot, game_tot = 0, 0, 0, 0
    host_str, net_wan = "OFFLINE", "OFFLINE"
    
    unmonitored = []

    for r in rows:
        n, t = r['entity_name'], r['entity_type']
        
        if r['is_enabled'] == 0 or r['status'] == 'paused':
            if t != 'host': unmonitored.append(n)
            continue
            
        is_up = (r['status'] == 'running')

        if t == 'network':
            if not is_up: net_down.append(n)
            if n == 'WAN_DNS' and is_up: net_wan = f"{r['ping_ms']:.0f}ms"
        elif t == 'host':
            if is_up: host_str = f"{r['cpu_usage']:.1f}% CPU | {r['mem_used']:.1f}GB RAM"
        elif t == 'vm':
            vms_tot += 1
            if not is_up: vm_down.append(n)
        elif t == 'lxc':
            lxc_tot += 1
            if not is_up: lxc_down.append(n)
        elif t == 'app':
            app_tot += 1
            if not is_up: app_down.append(n)
        elif t == 'game':
            game_tot += 1
            if not is_up: game_down.append(n)

    def fmt(tot, down): 
        return f"🟢 {tot - len(down)}/{tot} UP" if not down else f"🔴 {tot - len(down)}/{tot} UP [{', '.join(down)}]"

    msg = f"{title}\n\n"
    msg += f"🌐 <b>NETWORK:</b> {'🟢 ONLINE' if not net_down else '🔴 FAIL ['+', '.join(net_down)+']'} (WAN: {net_wan})\n"
    msg += f"🖥️ <b>HOST:</b> {host_str}\n"
    msg += f"📦 <b>VMs:</b> {fmt(vms_tot, vm_down)}\n"
    msg += f"📦 <b>LXCs:</b> {fmt(lxc_tot, lxc_down)}\n"
    msg += f"🔌 <b>WEB:</b> {fmt(app_tot, app_down)}\n"
    msg += f"🎮 <b>GAMES:</b> {fmt(game_tot, game_down)}"
    
    if unmonitored:
        msg += f"\n\n🔧 <b>UNMONITORED:</b> [{', '.join(unmonitored)}]"
    
    send_telegram(msg)
    print("-> Full Report Sent.", flush=True)

def check_ping(ip):
    try:
        output = subprocess.run(['ping', '-c', '3', '-W', '2', ip], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if output.returncode == 0:
            match = re.search(r'time=([\d\.]+)', output.stdout)
            return 'running', float(match.group(1)) if match else 0.0
        return 'stopped', 0.0
    except Exception: return 'stopped', 0.0

def check_tcp(ip, port):
    try:
        with socket.create_connection((ip, port), timeout=5): return 'running'
    except Exception: return 'stopped'

def prune_database():
    conn = sqlite3.connect(DB_NAME, timeout=15)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM metrics WHERE timestamp <= datetime('now', '-7 days')")
    conn.commit()
    conn.close()

def collect_and_store():
    conn = sqlite3.connect(DB_NAME, timeout=15)
    cursor = conn.cursor()
    cursor.execute("SELECT name, entity_type, target_address, port, uuid, is_enabled, down_since FROM monitored_targets")
    cfg = {(row[0], row[1]): {'ip': row[2], 'port': row[3], 'uuid': row[4], 'enabled': row[5], 'down_since': row[6]} for row in cursor.fetchall()}
    conn.close()
    
    metrics_batch = []
    downtime_updates = []
    new_entities = []
    now = time.time()

    def process_status(name, t, status, cpu=0.0, mu=0.0, mt=0.0, ping=0.0):
        metrics_batch.append((name, t, status, cpu, mu, mt, 0.0, 0.0, 0.0, 0.0, ping))
        db_down_since = cfg.get((name, t), {}).get('down_since', 0.0)
        if status == 'stopped' and db_down_since == 0.0:
            downtime_updates.append((now, name, t))
        elif status == 'running' and db_down_since != 0.0:
            downtime_updates.append((0.0, name, t))

    try:
        # NETWORK
        for (name, e_type), data in cfg.items():
            if e_type == 'network':
                if data['enabled'] == 0:
                    metrics_batch.append((name, 'network', 'paused', 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0))
                    process_alert(name, 'ping', False, 3, "", "")
                    continue
                status, ms = check_ping(data['ip'])
                process_status(name, 'network', status, ping=ms)
                process_alert(name, 'ping', status == 'stopped', 3, f"Network unreachable ({data['ip']}).", "Network is back online.")

        # PROXMOX
        proxmox_alive = False
        try:
            proxmox = ProxmoxAPI(PROXMOX_IP, user=TOKEN_ID.split('!')[0], token_name=TOKEN_ID.split('!')[1], token_value=TOKEN_SECRET, verify_ssl=False, timeout=7)
            my_node = proxmox.nodes.get()[0]['node']
            proxmox_alive = True
        except Exception:
            metrics_batch.append(('CORE-PVE', 'host', 'stopped', 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0))
            process_alert('CORE-PVE', 'api', True, 2, "Proxmox Hypervisor API unreachable.", "Proxmox API online.")
            
            for (name, e_type), data in cfg.items():
                if e_type in ['vm', 'lxc']:
                    metrics_batch.append((name, e_type, 'paused' if data['enabled'] == 0 else 'stopped', 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0))

        if proxmox_alive:
            process_alert('CORE-PVE', 'api', False, 2, "", "Proxmox API online.")
            node_status = proxmox.nodes(my_node).status.get()
            cpu, mt, mu = (node_status.get('cpu') or 0.0) * 100, (node_status.get('memory', {}).get('total') or 0.0) / (1024**3), (node_status.get('memory', {}).get('used') or 0.0) / (1024**3)
            metrics_batch.append(('CORE-PVE', 'host', 'running', cpu, mu, mt, 0.0, 0.0, 0.0, 0.0, 0.0))
            process_alert('CORE-PVE', 'cpu_90', cpu > THRESHOLD_PCT, 3, f"Host CPU critical at {cpu:.1f}%", "Host CPU normalized.")

            for lxc in proxmox.nodes(my_node).lxc.get():
                name = lxc.get('name', f"lxc-{lxc['vmid']}")
                if name in IGNORE_ENTITIES: continue
                
                if (name, 'lxc') not in cfg:
                    new_entities.append((name, 'lxc', 1))
                    cfg[(name, 'lxc')] = {'enabled': 1, 'down_since': 0.0}
                    
                if cfg[(name, 'lxc')]['enabled'] == 0:
                    metrics_batch.append((name, 'lxc', 'paused', 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0))
                    process_alert(name, 'cpu_90', False, 3, "", "")
                    continue

                status = lxc.get('status')
                if status == 'running':
                    l_cpu, l_mt, l_mu = (lxc.get('cpu') or 0.0) * 100, (lxc.get('maxmem') or 0.0) / (1024**3), (lxc.get('mem') or 0.0) / (1024**3)
                    process_status(name, 'lxc', status, cpu=l_cpu, mu=l_mu, mt=l_mt)
                    process_alert(name, 'cpu_90', l_cpu > THRESHOLD_PCT, 3, f"CPU critical at {l_cpu:.1f}%", "CPU normalized.")
                else:
                    process_status(name, 'lxc', status)
                    process_alert(name, 'cpu_90', False, 3, "", "")

            for vm in proxmox.nodes(my_node).qemu.get():
                name = vm.get('name', f"vm-{vm['vmid']}")
                if name in IGNORE_ENTITIES: continue
                
                if (name, 'vm') not in cfg:
                    new_entities.append((name, 'vm', 1))
                    cfg[(name, 'vm')] = {'enabled': 1, 'down_since': 0.0}
                    
                if cfg[(name, 'vm')]['enabled'] == 0:
                    metrics_batch.append((name, 'vm', 'paused', 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0))
                    process_alert(name, 'cpu_90', False, 3, "", "")
                    continue

                status = vm.get('status')
                if status == 'running':
                    try:
                        vm_status = proxmox.nodes(my_node).qemu(vm['vmid']).status.current.get()
                        v_cpu, v_mt, v_mu = (vm_status.get('cpu') or 0.0) * 100, (vm_status.get('maxmem') or 0.0) / (1024**3), (vm_status.get('mem') or 0.0) / (1024**3)
                    except Exception:
                        v_cpu, v_mt, v_mu = (vm.get('cpu') or 0.0) * 100, (vm.get('maxmem') or 0.0) / (1024**3), (vm.get('mem') or 0.0) / (1024**3)
                    
                    process_status(name, 'vm', status, cpu=v_cpu, mu=v_mu, mt=v_mt)
                    process_alert(name, 'cpu_90', v_cpu > THRESHOLD_PCT, 3, f"CPU critical at {v_cpu:.1f}%", "CPU normalized.")
                else:
                    process_status(name, 'vm', status)
                    process_alert(name, 'cpu_90', False, 3, "", "")

        # APPS
        for (name, e_type), data in cfg.items():
            if e_type == 'app':
                if data['enabled'] == 0:
                    metrics_batch.append((name, 'app', 'paused', 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0))
                    process_alert(name, 'tcp', False, 3, "", "")
                    continue
                status = check_tcp(data['ip'], data['port'])
                process_status(name, 'app', status)
                process_alert(name, 'tcp', status == 'stopped', 3, f"Service crashed ({data['ip']}:{data['port']}).", "Service responding.")

        # GAMES
        ptero_headers = {"Authorization": f"Bearer {PTERO_TOKEN}", "Accept": "application/json"}
        for (name, e_type), data in cfg.items():
            if e_type == 'game':
                if data['enabled'] == 0:
                    metrics_batch.append((name, 'game', 'paused', 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0))
                    process_alert(name, 'game_offline', False, 3, "", "")
                    process_alert(name, 'cpu_90', False, 3, "", "")
                    continue
                
                status = 'stopped'
                try:
                    res = requests.get(f"{PTERO_URL}/api/client/servers/{data['uuid']}/resources", headers=ptero_headers, timeout=7)
                    if res.status_code == 200:
                        r_data = res.json()['attributes']
                        status = 'running' if r_data['current_state'] == 'running' else 'stopped'
                        cpu, mem = r_data['resources'].get('cpu_absolute', 0.0), r_data['resources'].get('memory_bytes', 0.0) / (1024**3)
                        process_status(name, 'game', status, cpu=cpu, mu=mem)
                        process_alert(name, 'cpu_90', cpu > THRESHOLD_PCT, 3, f"Game CPU critical at {cpu:.1f}%", "Game CPU normalized.")
                    else: process_status(name, 'game', 'stopped')
                except Exception: process_status(name, 'game', 'stopped')
                process_alert(name, 'game_offline', status == 'stopped', 3, f"Game server {name} is offline.", f"Game server {name} is back online.", is_game=True)

    except Exception as e: print(f"-> Collection Error: {e}", flush=True)

    # 3. WRITE BATCH
    if metrics_batch or new_entities or downtime_updates:
        write_conn = sqlite3.connect(DB_NAME, timeout=15)
        write_cursor = write_conn.cursor()
        try:
            for name, e_type, enabled in new_entities:
                write_cursor.execute('INSERT OR IGNORE INTO monitored_targets (name, entity_type, is_enabled, down_since) VALUES (?, ?, ?, 0.0)', (name, e_type, enabled))
            for stamp, name, e_type in downtime_updates:
                write_cursor.execute('UPDATE monitored_targets SET down_since = ? WHERE name = ? AND entity_type = ?', (stamp, name, e_type))
            
            write_cursor.executemany('''INSERT INTO metrics (entity_name, entity_type, status, cpu_usage, mem_used, mem_total, disk_used, disk_total, net_in, net_out, ping_ms) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', metrics_batch)
            write_conn.commit()
        except Exception as e: print(f"-> DB Write Error: {e}", flush=True)
        finally: write_conn.close()

# --- ASYNC SMART BUTTON LOGIC ---
top_press_time = 0
mid_press_time = 0
bot_press_time = 0

def async_api_call(url, payload=None):
    def task():
        try:
            if payload: requests.post(url, json=payload, timeout=2)
            else: requests.post(url, timeout=2)
        except Exception: pass
    threading.Thread(target=task, daemon=True).start()

def btn_top_down(): global top_press_time; top_press_time = time.time()
def btn_top_up():
    dur = time.time() - top_press_time
    print(f"[GPIO 18] Top Button (Dur: {dur:.1f}s)", flush=True)
    async_api_call('http://127.0.0.1:8000/api/btn/top', {"is_long": dur > 2.0})

def btn_mid_down(): global mid_press_time; mid_press_time = time.time()
def btn_mid_up():
    dur = time.time() - mid_press_time
    print(f"[GPIO 23] Middle Button (Dur: {dur:.1f}s)", flush=True)
    if dur > 5.0:
        print("-> EXECUTING SYSTEM REBOOT...", flush=True)
        subprocess.run(['sudo', 'reboot'])
    else:
        def task():
            try:
                res = requests.post('http://127.0.0.1:8000/api/btn/mid', timeout=2)
                if res.json().get('action') == 'force_poll':
                    global FORCE_POLL_AND_REPORT
                    FORCE_POLL_AND_REPORT = True
            except Exception: pass
        threading.Thread(target=task, daemon=True).start()

def btn_bot_down(): global bot_press_time; bot_press_time = time.time()
def btn_bot_up():
    dur = time.time() - bot_press_time
    print(f"[GPIO 24] Bottom Button (Dur: {dur:.1f}s)", flush=True)
    async_api_call('http://127.0.0.1:8000/api/btn/bot', {"is_long": dur > 2.0})

if GPIO_AVAILABLE:
    try:
        btn_top = Button(18, bounce_time=0.05); btn_top.when_pressed = btn_top_down; btn_top.when_released = btn_top_up
        btn_mid = Button(23, bounce_time=0.05); btn_mid.when_pressed = btn_mid_down; btn_mid.when_released = btn_mid_up
        btn_bot = Button(24, bounce_time=0.05); btn_bot.when_pressed = btn_bot_down; btn_bot.when_released = btn_bot_up
    except Exception: pass

if __name__ == "__main__":
    print("=== CB456 HackNet Engine Started ===", flush=True)
    setup_database()
    
    loop_count = 0
    last_poll_time = 0

    try:
        while True:
            current_time = time.time()
            if FORCE_POLL_AND_REPORT or (current_time - last_poll_time >= POLL_INTERVAL):
                collect_and_store()
                last_poll_time = time.time()
                loop_count += 1
                
                if FORCE_POLL_AND_REPORT:
                    generate_full_report("📊 <b>NOC Manual Status Report (Fresh Data)</b>")
                    FORCE_POLL_AND_REPORT = False

            now = datetime.datetime.now()
            if now.hour == 8 and now.minute == 0 and LAST_DAILY_REPORT_DAY != now.day:
                generate_full_report("🌅 <b>HackNet Morning Status Report</b>")
                LAST_DAILY_REPORT_DAY = now.day

            if now.hour == 3 and now.minute == 0 and LAST_VACUUM_DAY != now.day:
                try:
                    conn = sqlite3.connect(DB_NAME, timeout=15)
                    conn.execute("VACUUM")
                    conn.close()
                except Exception: pass
                LAST_VACUUM_DAY = now.day

            if loop_count >= 360:
                prune_database()
                loop_count = 0

            time.sleep(0.2)
            
    except KeyboardInterrupt: pass
