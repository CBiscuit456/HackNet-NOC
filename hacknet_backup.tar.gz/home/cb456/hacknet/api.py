from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import sqlite3

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="static"), name="static")

DB_NAME = 'metrics.db'

# --- DATABASE STATE INITIALIZATION ---
def init_db():
    conn = sqlite3.connect(DB_NAME, timeout=15)
    cursor = conn.cursor()
    cursor.execute('PRAGMA journal_mode=WAL;')
    cursor.execute('PRAGMA synchronous=NORMAL;')
    
    cursor.execute('CREATE TABLE IF NOT EXISTS sys_state (key TEXT PRIMARY KEY, value TEXT)')
    cursor.execute('INSERT OR IGNORE INTO sys_state (key, value) VALUES ("page_trigger", "0")')
    cursor.execute('INSERT OR IGNORE INTO sys_state (key, value) VALUES ("filter_mode", "0")')
    cursor.execute('INSERT OR IGNORE INTO sys_state (key, value) VALUES ("ui_mode", "0")') 
    cursor.execute('INSERT OR IGNORE INTO sys_state (key, value) VALUES ("config_cursor", "0")')
    
    cursor.execute('''CREATE TABLE IF NOT EXISTS alert_state 
                      (entity_metric TEXT PRIMARY KEY, is_alerting INTEGER, first_alert_time REAL, last_alert_time REAL, count INTEGER)''')
    
    cursor.execute('''CREATE TABLE IF NOT EXISTS monitored_targets 
                      (name TEXT, entity_type TEXT, target_address TEXT, port INTEGER, uuid TEXT, is_enabled INTEGER DEFAULT 1, down_since REAL DEFAULT 0.0,
                      PRIMARY KEY(name, entity_type))''')
    
    conn.commit()
    conn.close()

init_db()

# --- UTILITY FUNCTIONS ---
def get_sys(key):
    conn = sqlite3.connect(DB_NAME, timeout=15)
    cursor = conn.cursor()
    cursor.execute('SELECT value FROM sys_state WHERE key = ?', (key,))
    val = cursor.fetchone()[0]
    conn.close()
    return int(val)

def set_sys(key, value):
    conn = sqlite3.connect(DB_NAME, timeout=15)
    cursor = conn.cursor()
    cursor.execute('UPDATE sys_state SET value = ? WHERE key = ?', (str(value), key))
    conn.commit()
    conn.close()

# --- WEB ADMIN ENDPOINTS ---
@app.get("/api/admin/targets")
def get_admin_targets():
    conn = sqlite3.connect(DB_NAME, timeout=15)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM monitored_targets ORDER BY entity_type ASC, LOWER(name) ASC')
    rows = cursor.fetchall()
    conn.close()
    return {"status": "success", "data": [dict(r) for r in rows]}

@app.post("/api/admin/targets")
async def add_admin_target(req: Request):
    try:
        data = await req.json()
        name = data.get("name")
        e_type = data.get("entity_type")
        ip = data.get("target_address", "")
        port = data.get("port", 0)
        uuid = data.get("uuid", "")
        
        conn = sqlite3.connect(DB_NAME, timeout=15)
        cursor = conn.cursor()
        cursor.execute('INSERT OR REPLACE INTO monitored_targets (name, entity_type, target_address, port, uuid, is_enabled, down_since) VALUES (?, ?, ?, ?, ?, 1, 0.0)', 
                       (name, e_type, ip, port, uuid))
        conn.commit()
        conn.close()
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.delete("/api/admin/targets")
async def delete_admin_target(req: Request):
    try:
        data = await req.json()
        name = data.get("name")
        e_type = data.get("entity_type")
        
        conn = sqlite3.connect(DB_NAME, timeout=15)
        cursor = conn.cursor()
        cursor.execute('DELETE FROM monitored_targets WHERE name = ? AND entity_type = ?', (name, e_type))
        cursor.execute('DELETE FROM metrics WHERE entity_name = ? AND entity_type = ?', (name, e_type))
        conn.commit()
        conn.close()
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": str(e)}

# --- SMART BUTTON ROUTING ---
@app.post("/api/btn/top")
async def btn_top(req: Request):
    data = await req.json()
    is_long = data.get("is_long", False)
    ui_mode = get_sys("ui_mode")
    
    if is_long:
        if ui_mode == 0:
            # RETURN TO HOME SHORTCUT
            set_sys("filter_mode", 0)
            set_sys("page_trigger", 9999)
    else:
        if ui_mode == 0:
            set_sys("page_trigger", get_sys("page_trigger") + 1)
        else:
            # SCROLL CONFIG
            conn = sqlite3.connect(DB_NAME, timeout=15)
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM monitored_targets WHERE entity_type != 'host'")
            total = cursor.fetchone()[0]
            conn.close()
            curr = get_sys("config_cursor")
            set_sys("config_cursor", (curr + 1) % max(1, total))
    return {"status": "success"}

@app.post("/api/btn/mid")
async def btn_mid():
    ui_mode = get_sys("ui_mode")
    if ui_mode == 0:
        return {"status": "success", "action": "force_poll"}
    else:
        # TOGGLE TARGET
        conn = sqlite3.connect(DB_NAME, timeout=15)
        cursor = conn.cursor()
        cursor.execute("SELECT name, entity_type, is_enabled FROM monitored_targets WHERE entity_type != 'host' ORDER BY entity_type ASC, LOWER(name) ASC")
        targets = cursor.fetchall()
        curr = get_sys("config_cursor")
        if curr < len(targets):
            t_name, t_type, t_enabled = targets[curr]
            new_state = 0 if t_enabled == 1 else 1
            cursor.execute('UPDATE monitored_targets SET is_enabled = ?, down_since = 0.0 WHERE name = ? AND entity_type = ?', (new_state, t_name, t_type))
            conn.commit()
        conn.close()
        return {"status": "success", "action": "toggled"}

@app.post("/api/btn/bot")
async def btn_bot(req: Request):
    data = await req.json()
    is_long = data.get("is_long", False)
    ui_mode = get_sys("ui_mode")
    
    if is_long:
        if ui_mode == 0:
            # ENTER CONFIG MODE
            set_sys("ui_mode", 1)
            set_sys("config_cursor", 0)
    else:
        if ui_mode == 0:
            filt = get_sys("filter_mode")
            set_sys("filter_mode", 0 if filt == 1 else 1)
        else:
            # EXIT CONFIG MODE
            set_sys("ui_mode", 0)
    return {"status": "success"}

# --- UI & DATA ENDPOINTS ---
@app.get("/api/kiosk/state")
def get_kiosk_state():
    conn = sqlite3.connect(DB_NAME, timeout=15)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT key, value FROM sys_state')
    state = {r['key']: int(r['value']) for r in cursor.fetchall()}
    
    cursor.execute("SELECT * FROM monitored_targets WHERE entity_type != 'host' ORDER BY entity_type ASC, LOWER(name) ASC")
    targets = [dict(r) for r in cursor.fetchall()]
    conn.close()
    
    return {"status": "success", "state": state, "targets": targets}

@app.get("/")
def serve_dashboard(): return FileResponse("static/index.html")
@app.get("/kiosk")
def serve_kiosk(): return FileResponse("static/kiosk.html")
@app.get("/admin")
def serve_admin(): return FileResponse("static/admin.html")

@app.get("/api/live")
def live_data():
    conn = sqlite3.connect(DB_NAME, timeout=15)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('''
        SELECT m.*, t.is_enabled, t.down_since
        FROM metrics m
        LEFT JOIN monitored_targets t ON m.entity_name = t.name AND m.entity_type = t.entity_type
        WHERE m.id IN (
            SELECT MAX(id) FROM metrics 
            WHERE timestamp >= datetime('now', '-2 minutes') GROUP BY entity_name, entity_type
        ) ORDER BY m.entity_type ASC, LOWER(m.entity_name) ASC
    ''')
    rows = cursor.fetchall()
    conn.close()
    return {"status": "success", "data": [dict(r) for r in rows]}
